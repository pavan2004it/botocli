from .awssnap import cli
