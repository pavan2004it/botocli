import boto3
import ast
import botocore
import click
import datetime
import collections
from botocore.exceptions import ClientError
import botocore
s3 = boto3.resource('s3')
s3c = boto3.client('s3')
ec2 = boto3.resource('ec2')
ec = boto3.client('ec2')
elbList = boto3.client('elbv2')
costexplorer = boto3.client('ce')
classicelblist = boto3.client('elb')
dbs = boto3.client('rds')
rs = boto3.client('redshift')
rgapi = boto3.client('resourcegroupstaggingapi')


def list_ebssnapshots():
    count = 0
    result = ec.describe_snapshots(Filters=[{'Name': 'owner-id', 'Values': ['672985825598']}])
    for snapshot in result['Snapshots']:
        count += 1
    return 'Total Number of snapshots are {0}'.format(count)


def delete_snapshots(days):
    count = 0
    now = datetime.datetime.utcnow().date()
    result = ec.describe_snapshots(Filters=[{'Name': 'owner-id', 'Values': ['672985825598']}])


    for snapshot in result['Snapshots']:
        try:
            a = now - snapshot['StartTime'].date()
            if a.days >= days:
                snapid = snapshot['SnapshotId']
                print('Deleting Snapshot {0}'.format(snapshot['SnapshotId']))
                ec.delete_snapshot(SnapshotId=snapid)
                print('Deleted Snapshot {0}'.format(snapshot['SnapshotId']))
        except botocore.exceptions.ClientError as e:
            print(" Could not delete the snapshot {0}. ".format(snapshot['SnapshotId']) + str(e))
            continue

    return 'Snapshots Deleted Successfully'

"""
def sh_servicecost(project,day,environment):
    ct = []
    keys = []
    values = []
    f = []
    i = 0
    #j = 0
    now = datetime.datetime.utcnow()
    start = (now - datetime.timedelta(days=int(day))).strftime('%Y-%m-%d')
    end = now.strftime('%Y-%m-%d')
    costs = costexplorer.get_cost_and_usage(TimePeriod={'Start':start,'End':end},Granularity='MONTHLY',Filter={"And":[{"Tags":{'Key':'Cost Center','Values':[project]}},{"Tags":{'Key':'Environment','Values':[environment]}}]},Metrics=['UnblendedCost'],GroupBy=[{'Type':'DIMENSION','Key':'SERVICE'}])
    n = len(costs['ResultsByTime'])
    while i <= n - 1:
        for cost in costs['ResultsByTime'][i]['Groups']:
            keys.append(cost['Keys'])
            values.append(float(cost['Metrics']['UnblendedCost']['Amount']))
        i +=1

    for element in keys:
        f.append(element[0])
    #result = [(c, d) for c, d in zip(f, values)]

    res = collections.defaultdict(list)

    for a, b in zip(f, values):
        res[a].append(b)
    x = dict(res)
    total_cost = sum(values)
    e = {k: sum(float(i) for i in v) for v in x.values() for (k, v) in x.items()}
    for r,v in e.items():
        print('The Cost of Service {0} is {1} for the {2} Project'.format(r,v,project))
    #return 'This data was for {0} days'.format(day)
    return 'The Total Cost incurred by {2} environment of project {0} is {1} USD'.format(project,total_cost,environment)
"""

def total_cost(costcenter,day):
    ct = []
    now = datetime.datetime.utcnow()
    start = (now - datetime.timedelta(days=int(day))).strftime('%Y-%m-%d')
    end = now.strftime('%Y-%m-%d')
    costs = costexplorer.get_cost_and_usage(TimePeriod={'Start':start,'End':end},Granularity='MONTHLY',Filter={'Tags':{'Key':'Cost Center','Values':[costcenter]}},Metrics=['UnblendedCost'])
    for cost in costs['ResultsByTime']:
        x = cost['Total']['UnblendedCost']['Amount']
        ct.append(float(x))
    cost_total = sum(ct)
    projectsafety = ['Pvtrace','Asrtrace','Abcube','Littrace','Sigtrace']
    projectctg = ['Clinfeed']
    projectirt = ['Trident']
    projectit = ['IT']
    projectdevops = ['Devops']
    projectintegration = ["Ps-Integration"]
    if(costcenter=="Safety"):
        for p in projectsafety:
            cost_safety = project_totalcost(p, day)
            print(cost_safety)
    elif(costcenter=="CTG"):
        for p in projectctg:
            cost_ctg = project_totalcost(p, day)
            print(cost_ctg)
    elif(costcenter=="IT"):
        for p in projectit:
            cost_it = project_totalcost(p, day)
            print(cost_it)
    elif(costcenter=="IRT"):
        for p in projectirt:
            cost_irt = project_totalcost(p, day)
            print(cost_irt)
    elif(costcenter=="Devops"):
        for p in projectdevops:
            cost_devops = project_totalcost(p, day)
            print(cost_devops)
    elif(costcenter=="Ps-Integration"):
        for p in projectintegration:
            cost_integration = project_totalcost(p, day)
            print(cost_integration)
    return "\nThe total cost for the {0} Cost Center is {1} USD  for the duration of {2} days".format(costcenter,cost_total,day)

def sh_project_cost_with_dimensions(project,day):
    ct = []
    keys = []
    values = []
    f = []
    i = 0
    #j = 0
    now = datetime.datetime.utcnow()
    start = (now - datetime.timedelta(days=int(day))).strftime('%Y-%m-%d')
    end = now.strftime('%Y-%m-%d')
    costs = costexplorer.get_cost_and_usage(TimePeriod={'Start':start,'End':end},Granularity='MONTHLY',Filter={"Tags":{'Key':'Project','Values':[project]}},Metrics=['UnblendedCost'],GroupBy=[{'Type':'DIMENSION','Key':'SERVICE'}])
    n = len(costs['ResultsByTime'])
    while i <= n - 1:
        for cost in costs['ResultsByTime'][i]['Groups']:
            keys.append(cost['Keys'])
            values.append(float(cost['Metrics']['UnblendedCost']['Amount']))
        i +=1

    for element in keys:
        f.append(element[0])
    #result = [(c, d) for c, d in zip(f, values)]

    res = collections.defaultdict(list)

    for a, b in zip(f, values):
        res[a].append(b)
    x = dict(res)
    total_cost = sum(values)
    e = {k: sum(float(i) for i in v) for v in x.values() for (k, v) in x.items()}
    for r,v in e.items():
        print('The Cost of Service {0} is {1} for the {2} Project'.format(r,v,project))
    #return 'This data was for {0} days'.format(day)
    return '\nThe Total Cost incurred by project {0} is {1} USD'.format(project,total_cost)


def sh_projectcost_with_env(project,day,environment):
    ct = []
    keys = []
    values = []
    f = []
    i = 0
    #j = 0
    now = datetime.datetime.utcnow()
    start = (now - datetime.timedelta(days=int(day))).strftime('%Y-%m-%d')
    end = now.strftime('%Y-%m-%d')
    costs = costexplorer.get_cost_and_usage(TimePeriod={'Start':start,'End':end},Granularity='MONTHLY',Filter={"And":[{"Tags":{'Key':'Project','Values':[project]}},{"Tags":{'Key':'Environment','Values':[environment]}}]},Metrics=['UnblendedCost'],GroupBy=[{'Type':'DIMENSION','Key':'SERVICE'}])
    n = len(costs['ResultsByTime'])
    while i <= n - 1:
        for cost in costs['ResultsByTime'][i]['Groups']:
            keys.append(cost['Keys'])
            values.append(float(cost['Metrics']['UnblendedCost']['Amount']))
        i +=1

    for element in keys:
        f.append(element[0])
    #result = [(c, d) for c, d in zip(f, values)]

    res = collections.defaultdict(list)

    for a, b in zip(f, values):
        res[a].append(b)
    x = dict(res)
    total_cost = sum(values)
    e = {k: sum(float(i) for i in v) for v in x.values() for (k, v) in x.items()}
    for r,v in e.items():
        print('The Cost of Service {0} is {1} for the {2} Project'.format(r,v,project))
    #return 'This data was for {0} days'.format(day)
    return '\nThe Total Cost incurred by {2} environment of project {0} is {1} USD'.format(project,total_cost,environment)

def project_totalcost(project,day):
    ct = []
    now = datetime.datetime.utcnow()
    start = (now - datetime.timedelta(days=int(day))).strftime('%Y-%m-%d')
    end = now.strftime('%Y-%m-%d')
    costs = costexplorer.get_cost_and_usage(TimePeriod={'Start':start,'End':end},Granularity='MONTHLY',Filter={'Tags':{'Key':'Project','Values':[project]}},Metrics=['UnblendedCost'])
    for cost in costs['ResultsByTime']:
        x = cost['Total']['UnblendedCost']['Amount']
        ct.append(float(x))
    cost_total = sum(ct)
    return "\nThe total cost for the {0} Project is {1} USD  for the duration of {2} days".format(project,cost_total,day)


"""
def sh_servicecost(project,costcenter,day,environment):
    ct = []
    keys = []
    values = []
    f = []
    i = 0
    #j = 0
    now = datetime.datetime.utcnow()
    start = (now - datetime.timedelta(days=int(day))).strftime('%Y-%m-%d')
    end = now.strftime('%Y-%m-%d')
    costs = costexplorer.get_cost_and_usage(TimePeriod={'Start':start,'End':end},Granularity='MONTHLY',Filter={"And":[{"And":[{"Tags":{'Key':'Project','Values':[project]}},{"Tags":{'Key':'Cost Center','Values':[costcenter]}}]},{"Tags":{'Key':'Environment','Values':[environment]}}]},Metrics=['UnblendedCost'],GroupBy=[{'Type':'DIMENSION','Key':'SERVICE'}])
    n = len(costs['ResultsByTime'])
    while i <= n - 1:
        for cost in costs['ResultsByTime'][i]['Groups']:
            keys.append(cost['Keys'])
            values.append(float(cost['Metrics']['UnblendedCost']['Amount']))
        i +=1

    for element in keys:
        f.append(element[0])
    #result = [(c, d) for c, d in zip(f, values)]

    res = collections.defaultdict(list)

    for a, b in zip(f, values):
        res[a].append(b)
    x = dict(res)
    total_cost = sum(values)
    e = {k: sum(float(i) for i in v) for v in x.values() for (k, v) in x.items()}
    for r,v in e.items():
        print('The Cost of Service {0} is {1} for the {2} Project'.format(r,v,project))
    #return 'This data was for {0} days'.format(day)
    return 'The Total Cost incurred by {2} environment of project {0} is {1} USD'.format(project,total_cost,environment)
"""

def sh_dimension():
    now = datetime.datetime.utcnow()
    start = (now - datetime.timedelta(days=int(10))).strftime('%Y-%m-%d')
    end = now.strftime('%Y-%m-%d')
    dimensions = costexplorer.get_dimension_values(TimePeriod={
        'Start': start,
        'End': end
    }, Dimension='USAGE_TYPE_GROUP')
    return dimensions

def del_dbs(dname,fsnap):
    now = datetime.datetime.utcnow().strftime('%Y-%m-%d')
    if fsnap in ['true','t','True']:
        fsnap = ast.literal_eval("True")
        db = dbs.delete_db_instance(
    DBInstanceIdentifier=dname,
    SkipFinalSnapshot=fsnap,
)
    elif fsnap in ['false','f','False']:
        fsnap = ast.literal_eval("False")
        db = dbs.delete_db_instance(
    DBInstanceIdentifier=dname,
    SkipFinalSnapshot=fsnap,
    FinalDBSnapshotIdentifier=dname + '-' + now
)

    return db


def tag_dbs(name):
    filter = [{'Key':'Name','Values':[name]}]
    dbinstance = rgapi.get_resources(TagFilters=filter,ResourceTypeFilters=['rds:db'])

    for db in dbinstance['ResourceTagMappingList']:
        return db['ResourceARN']





def create_db(storage,iclass,identifier,username,password,engine,sg,dbsg):
    rdsdb = dbs.create_db_instance(AllocatedStorage=int(storage),
    DBInstanceClass=iclass,
    DBInstanceIdentifier=identifier,
    MasterUserPassword=password,
    MasterUsername=username,
    Engine=engine,
    LicenseModel='license-included',
    VpcSecurityGroupIds=[sg],
    DBSubnetGroupName=dbsg,
    Tags=[
        {
            'Key': 'Name',
            'Value': identifier
        },
    ])

    return rdsdb


def mod_pg(pname,pvalue,am,gname):

    test = {'ParameterName':pname,'ParameterValue':pvalue,'ApplyMethod':am}
    i = 0
    while i < len(pname):
        test['ParameterName'] = pname[i]
        test['ParameterValue'] = pvalue[i]
        test['ApplyMethod'] = am[i]
        i+= 1
        pgroups = dbs.modify_db_parameter_group(DBParameterGroupName=gname,Parameters=[test])
    return pgroups

def filter_dbs(project,env):
    db = []
    if project:
        filter = [{'Key':'Cost Center','Values':[project]},{'Key':'Environment','Values':[env]}]
        dbinstance = rgapi.get_resources(TagFilters=filter,ResourceTypeFilters=['rds:db'])
    else:
        dbinstance = dbs.describe_db_instances()

    return dbinstance

"""
def sh_cost(project,day,dimension):
    ct = []
    now = datetime.datetime.utcnow()
    start = (now - datetime.timedelta(days=int(day))).strftime('%Y-%m-%d')
    end = now.strftime('%Y-%m-%d')
    costs = costexplorer.get_cost_and_usage(TimePeriod={'Start':start,'End':end},Granularity='DAILY',Filter={"And":[{"Dimensions":{'Key':'USAGE_TYPE_GROUP','Values':[dimension]}},{"Tags":{'Key':'Cost Center','Values':[project]}}]},Metrics=['UnblendedCost'])
    for cost in costs['ResultsByTime']:
        print(cost)
    return ct

def sh_cost_with_dimension_costcenter(costcenter,day,dimension,environment):
    ct = []
    now = datetime.datetime.utcnow()
    start = (now - datetime.timedelta(days=int(day))).strftime('%Y-%m-%d')
    end = now.strftime('%Y-%m-%d')
    costs = costexplorer.get_cost_and_usage(TimePeriod={'Start':start,'End':end},Granularity='DAILY',Filter={"And":[{"Dimensions":{'Key':'USAGE_TYPE_GROUP','Values':[dimension]}},{"Tags":{'Key':'Cost Center','Values':[costcenter]}},{"Tags":{'Key':'Environment','Values':[environment]}}]},Metrics=['UnblendedCost'],GroupBy=[{'Type':'TAG','Key':'Environment'}])
    for cost in costs['ResultsByTime']:
        for value in cost['Groups']:
            x = value['Metrics']['UnblendedCost']['Amount']
            ct.append(float(x))
    cost_total = sum(ct)
    return "The Total Cost for the {3} environment of Project {0} is {1} USD for the Dimension {4}".format(costcenter,cost_total,day,environment,dimension)





def total_cost(project,day):
    ct = []
    now = datetime.datetime.utcnow()
    start = (now - datetime.timedelta(days=int(day))).strftime('%Y-%m-%d')
    end = now.strftime('%Y-%m-%d')
    costs = costexplorer.get_cost_and_usage(TimePeriod={'Start':start,'End':end},Granularity='MONTHLY',Filter={'Tags':{'Key':'Cost Center','Values':[project]}},Metrics=['UnblendedCost'])
    for cost in costs['ResultsByTime']:
        x = cost['Total']['UnblendedCost']['Amount']
        ct.append(float(x))
    cost_total = sum(ct)
    return "The total cost for the {0} project is {1} USD  for the duration of {2} days".format(project,cost_total,day)
"""

def filter_instances(project,env):
    instances = []

    if project:
        filters = [{'Name':'tag:Cost Center', 'Values':[project]},{'Name':'tag:Environment', 'Values':[env]}]
        instances = ec2.instances.filter(Filters=filters)
    else:
        instances = ec2.instances.all()

    return instances

def list_tg(lb):
    tgt  = []
    loadbalancers = elbList.describe_load_balancers(Names=[lb])
    for lb in loadbalancers['LoadBalancers']:
        lbalancer = lb['LoadBalancerName']
        lbalancerarn = lb['LoadBalancerArn']
        tgs = elbList.describe_target_groups(LoadBalancerArn=lbalancerarn)
        for tg in tgs['TargetGroups']:
            targetgps = tg['TargetGroupArn']
            print(targetgps)
    return tgt

def rmv_tg(lb):
    tgt  = []
    loadbalancers = elbList.describe_load_balancers(Names=[lb])
    for lb in loadbalancers['LoadBalancers']:
        lbalancer = lb['LoadBalancerName']
        lbalancerarn = lb['LoadBalancerArn']
        tgs = elbList.describe_target_groups(LoadBalancerArn=lbalancerarn)
        for tg in tgs['TargetGroups']:
            targetgps = tg['TargetGroupArn']
            print(targetgps)
    return targetgps

def rmv_tgts(lb):
    test = []
    loadbalancers = elbList.describe_load_balancers(Names=[lb])
    for lb in loadbalancers['LoadBalancers']:
        lbalancer = lb['LoadBalancerName']
        lbalancerarn = lb['LoadBalancerArn']
        tgs = elbList.describe_target_groups(LoadBalancerArn=lbalancerarn)
        for tg in tgs['TargetGroups']:
            targetgps = tg['TargetGroupArn']
            tgts = elbList.describe_target_health(TargetGroupArn=targetgps)
            for tgt in tgts['TargetHealthDescriptions']:
                target_id = tgt['Target']['Id']
                print(target_id)
        return target_id



def list_targets(lb):
    test = []
    loadbalancers = elbList.describe_load_balancers(Names=[lb])
    for lb in loadbalancers['LoadBalancers']:
        lbalancer = lb['LoadBalancerName']
        lbalancerarn = lb['LoadBalancerArn']
        tgs = elbList.describe_target_groups(LoadBalancerArn=lbalancerarn)
        for tg in tgs['TargetGroups']:
            targetgps = tg['TargetGroupArn']
            print(targetgps)
            tgts = elbList.describe_target_health(TargetGroupArn=targetgps)
            for tgt in tgts['TargetHealthDescriptions']:
                target_id = tgt['Target']['Id']
                print(target_id)
    return test



def has_pending_snapshot(volume):
    snapshots = list(volume.snapshots.all())
    return snapshots and snapshots[0].state == 'pending'


def tar_instances(project):
    instances = []
    if project:
        filters = [{'Name':'tag:Cost Center', 'Values':[project]}]
        instances = ec2.instances.filter(Filters=filters)
    else:
        instances = ec2.instances.all()

    return instances

"""
def lst_targets(project):
     loadbalancers = elbList.describe_target_health(TargetGroupArn='arn:aws:elasticloadbalancing:eu-west-1:672985825598:targetgroup/test/4ae1eee6118aae2e')
     "list the targets"
     for target in loadbalancers['TargetHealthDescriptions']:
         target_id = target['Target']['Id']

     return target_id

"""

def find_replace_rs_tag(tagname):
    rsresponse = rs.describe_clusters(ClusterIdentifier='')
    count = 0
    print("The Clusters with no Tag are: \n")
    for r in rsresponse['Clusters']:
        y = [z['Key'] for z in r['Tags']]
        if (y.count(tagname) == 0):
            print(r['ClusterIdentifier'])
            name = r['ClusterIdentifier']
            userresponse = click.prompt("\nDo you wish to add the tags now (yes/no) ")
            if (userresponse=="yes"):
                value = click.prompt("\nWhat value of " + tagname  +   " you wish to enter ")
                resourcename = 'arn:aws:redshift:us-east-1:672985825598:cluster:{0}'.format(name)
                tagresponse = rs.create_tags(ResourceName=resourcename, Tags=[{'Key': tagname, 'Value': value}])
                if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                   print("\nResource " + r['ClusterIdentifier']  + " tagged with Tag value of " + value)

def find_replace_ec2_tag(tagname):
    ec2 = boto3.client('ec2')
    response = ec2.describe_instances()
    count = 0
    print("The Number of Instances with no Tag " + tagname + " are:\n")
    for r in response['Reservations']:
        y = [z['Key'] for z in r['Instances'][0]['Tags']]
        c = [d['Value'] for d in r['Instances'][0]['Tags'] if d['Key']=="Name"]
        if (y.count(tagname) == 0):
            print(r['Instances'][0]['InstanceId'])
            print(c)
            userresponse = click.prompt("Do you wish to add the tags now (yes/no) ")
            if(userresponse=="yes"):
                value = click.prompt("\nWhat value of " + tagname  +   " you wish to enter ")
                tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],Tags=[{'Key':tagname,'Value':value}])
                if(tagresponse['ResponseMetadata']['HTTPStatusCode']==200):
                    print("\nResource " +  r['Instances'][0]['InstanceId'] +  " tagged with Tag value of " + value)

                exitstatus = click.prompt("Do you want to exit(yes/no) ")
                if (exitstatus == "yes"):
                    break;
                else:
                    continue

            elif(userresponse=="no"):
                exitstatus = click.prompt("Do you want to exit(yes/no) ")
                if (exitstatus == "yes"):
                    break;
                else:
                    continue



def find_replace_untagged(tagname,service):
    if(service=="ec2"):
        find_replace_ec2_tag(tagname)
        return "\nOperation Complete !!!"
    elif(service=="rs"):
        find_replace_rs_tag(tagname)
        return "\nOperation Complete !!!"
    elif(service=="s3"):
        find_add_s3_tags(tagname)
        return "\nOperation Complete !!!"

def find_rs_tags(tagname):
    rsresponse = rs.describe_clusters(ClusterIdentifier='')
    count = 0
    print("The Clusters with no Tag are: \n")
    for r in rsresponse['Clusters']:
        y = [z['Key'] for z in r['Tags']]
        if (y.count(tagname) == 0):
            print(r['ClusterIdentifier'])

def find_ec2_tags(tagname):
    ec2 = boto3.client('ec2')
    response = ec2.describe_instances()
    count = 0
    print("The Number of Instances with no Tag " + tagname + " are:\n")
    for r in response['Reservations']:
        y = [z['Key'] for z in r['Instances'][0]['Tags']]
        c = [d['Value'] for d in r['Instances'][0]['Tags'] if d['Key']=="Name"]
        if (y.count(tagname) == 0):
            print(r['Instances'][0]['InstanceId'])


def create_tags_for_notagresources(service):
    if(service=="s3"):
        find_create_s3_tagset()
        return "\nOperation Complete !!!"

def auto_create_tags(service):
    if(service=="s3"):
        auto_create_s3_tagset()
        return "\nOperation Complete !!!"
    elif(service=="rs"):
        rsc_create_tag_automatically()
        return "\nOperation Complete!!!"

def rsc_create_tag_automatically():
    response = rs.describe_clusters()

    for r in response['Clusters']:
        if (len(r['Tags']) == 0):
            print("Cluster " + r['ClusterIdentifier'] + " has no tags")
            userresponse = click.prompt("\nDo you wish to add the tags now (yes/no) ")
            name = r['ClusterIdentifier']
            resourcename = 'arn:aws:redshift:us-east-1:672985825598:cluster:{0}'.format(name)
            if (name.lower().find("ds") >= 0 or name.lower().find("reports") >= 0):
                tagresponse = rs.create_tags(ResourceName=resourcename,
                               Tags=[{'Key': 'Name', 'Value': name}, {'Key': 'Project', 'Value': 'Reporting'},
                                     {'Key': 'Cost Center', 'Value': 'Reporting'}])
                if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                    print("\nResource " + name + " tagged ")


        elif ((len(r['Tags']) > 0)):
            print("\nCluster " + r['ClusterIdentifier'] + " has " + str(len(r['Tags'])) + " tags mentioned below: ")
            for tag in r['Tags']:
                print(tag)

        else:
            tagresponseunknown = rs.create_tags(ResourceName=resourcename,
                                                Tags=[{'Key': 'Name', 'Value': name},
                                                      {'Key': 'Project', 'Value': 'Unknown'},
                                                      {'Key': 'Cost Center', 'Value': 'Unknown'}])

            if (tagresponseunknown['ResponseMetadata']['HTTPStatusCode'] == 200):
                print("\nResource " + name + " tagged with unknown value")
"""
def rsc_create_tag_automatically():
    response = rs.describe_clusters()
    print("Tagging the redshift cluster with no tags: ")
    for r in response['Clusters']:
        if (len(r['Tags']) == 0):
            print("Cluster " + r['ClusterIdentifier'] + " has no tags")
            userresponse = click.prompt("\nDo you wish to add the tags now (yes/no) ")
            name = r['ClusterIdentifier']
            resourcename = 'arn:aws:redshift:us-east-1:672985825598:cluster:{0}'.format(name)
            if (name.lower().find("ds") >= 0 or name.lower().find("reports") >= 0):
                tagresponse = rs.create_tags(ResourceName=resourcename,
                               Tags=[{'Key': 'Name', 'Value': name}, {'Key': 'Project', 'Value': 'Reporting'},
                                     {'Key': 'Cost Center', 'Value': 'Reporting'}])
                if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                    print("\nResource " + name + " tagged ")

            else:
                tagresponseunknown = rs.create_tags(ResourceName=resourcename,
                               Tags=[{'Key': 'Name', 'Value': name}, {'Key': 'Project', 'Value': 'Unknown'},
                                     {'Key': 'Cost Center', 'Value': 'Unknown'}])

                if (tagresponseunknown['ResponseMetadata']['HTTPStatusCode'] == 200):
                    print("\nResource " + name + " tagged with unknown value")

"""

def auto_create_s3_tagset():
    s3 = boto3.resource('s3')
    s3c = boto3.client('s3')
    bucket_name = []
    for bucket in s3.buckets.all():
        bucket_name.append(bucket.name)
    print("Adding Tags for the buckets which don't have any tags: ")
    for bucket in bucket_name:
        try:
            s3c.get_bucket_tagging(Bucket=bucket)
        except ClientError:
            print(bucket)
            bucketname = bucket
            userresponse = click.prompt("\nDo you wish to add the tags now (yes/no) ")
            if (userresponse == "yes"):
                if (bucketname.lower().find("devops") >= 0):
                    costcentername = "Devops"
                    projectname = "Devops"
                    tagresponse = s3c.put_bucket_tagging(Bucket=bucket,
                                                         Tagging={'TagSet': [
                                                             {'Key': 'Cost Center', 'Value': costcentername},
                                                             {'Key': 'Project', 'Value': projectname},
                                                             {'Key': 'Name', 'Value': bucket}]})
                    if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 204):
                        print(
                            "\nResource " + bucket.upper() + " tagged with Cost Center value of " + "devops ".upper() + " and project value of  " + " devops ".upper() + " and the bucket name " + bucket.upper())

                elif (bucketname.lower().find("pvtrace") >= 0 or bucketname.lower().find("elastic") >= 0):
                    costcentername = "Safety"
                    projectname = "Pvtrace"
                    tagresponse = s3c.put_bucket_tagging(Bucket=bucket,
                                                         Tagging={'TagSet': [
                                                             {'Key': 'Cost Center', 'Value': costcentername},
                                                             {'Key': 'Project', 'Value': projectname},
                                                             {'Key': 'Name', 'Value': bucket}]})
                    if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 204):
                        print(
                            "\nResource " + bucket.upper() + " tagged with Cost Center value of " + costcentername.upper() + " and project value of  " + projectname.upper() + " and the bucket name " + bucket.upper())

                elif (bucketname.lower().find("safety") >= 0):
                    costcentername = "Safety"
                    projectname = "Safety"
                    tagresponse = s3c.put_bucket_tagging(Bucket=bucket,
                                                         Tagging={'TagSet': [
                                                             {'Key': 'Cost Center', 'Value': costcentername},
                                                             {'Key': 'Project', 'Value': projectname},
                                                             {'Key': 'Name', 'Value': bucket}]})
                    if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 204):
                        print(
                            "\nResource " + bucket.upper() + " tagged with Cost Center value of " + costcentername.upper() + " and project value of  " + projectname.upper() + " and the bucket name " + bucket.upper())

                elif (bucketname.lower().find("littrace") >= 0):
                    costcentername = "Safety"
                    projectname = "Littrace"
                    tagresponse = s3c.put_bucket_tagging(Bucket=bucket,
                                                         Tagging={'TagSet': [
                                                             {'Key': 'Cost Center', 'Value': costcentername},
                                                             {'Key': 'Project', 'Value': projectname},
                                                             {'Key': 'Name', 'Value': bucket}]})
                    if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 204):
                        print(
                            "\nResource " + bucket.upper() + " tagged with Cost Center value of " + costcentername.upper() + " and project value of  " + projectname.upper() + " and the bucket name " + bucket.upper())


                elif (bucketname.lower().find("sigtrace") >= 0):
                    costcentername = "Safety"
                    projectname = "Sigtrace"
                    tagresponse = s3c.put_bucket_tagging(Bucket=bucket,
                                                         Tagging={'TagSet': [
                                                             {'Key': 'Cost Center', 'Value': costcentername},
                                                             {'Key': 'Project', 'Value': projectname},
                                                             {'Key': 'Name', 'Value': bucket}]})
                    if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 204):
                        print(
                            "\nResource " + bucket.upper() + " tagged with Cost Center value of " + costcentername.upper() + " and project value of  " + projectname.upper() + " and the bucket name " + bucket.upper())


                elif (bucketname.lower().find("asrtrace") >= 0):
                    costcentername = "Safety"
                    projectname = "Asrtrace"
                    tagresponse = s3c.put_bucket_tagging(Bucket=bucket,
                                                         Tagging={'TagSet': [
                                                             {'Key': 'Cost Center', 'Value': costcentername},
                                                             {'Key': 'Project', 'Value': projectname},
                                                             {'Key': 'Name', 'Value': bucket}]})
                    if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 204):
                        print(
                            "\nResource " + bucket.upper() + " tagged with Cost Center value of " + costcentername.upper() + " and project value of  " + projectname.upper() + " and the bucket name " + bucket.upper())

                elif (bucketname.lower().find("safetyeasy") >= 0 or bucketname.lower().find("abcube") >= 0):
                    costcentername = "Safety"
                    projectname = "Abcube"
                    tagresponse = s3c.put_bucket_tagging(Bucket=bucket,
                                                         Tagging={'TagSet': [
                                                             {'Key': 'Cost Center', 'Value': costcentername},
                                                             {'Key': 'Project', 'Value': projectname},
                                                             {'Key': 'Name', 'Value': bucket}]})
                    if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 204):
                        print(
                            "\nResource " + bucket.upper() + " tagged with Cost Center value of " + costcentername.upper() + " and project value of  " + projectname.upper() + " and the bucket name " + bucket.upper())

                elif (bucketname.lower().find("clinfeed") >= 0 or bucketname.lower().find("ctg") >= 0):
                    costcentername = "CTG"
                    projectname = "Clinfeed"
                    tagresponse = s3c.put_bucket_tagging(Bucket=bucket,
                                                         Tagging={'TagSet': [
                                                             {'Key': 'Cost Center', 'Value': costcentername},
                                                             {'Key': 'Project', 'Value': projectname},
                                                             {'Key': 'Name', 'Value': bucket}]})
                    if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 204):
                        print(
                            "\nResource " + bucket.upper() + " tagged with Cost Center value of " + costcentername.upper() + " and project value of  " + projectname.upper() + " and the bucket name " + bucket.upper())


                elif (bucketname.lower().find("irt") >= 0 or bucketname.lower().find("trident") >= 0):
                    costcentername = "IRT"
                    projectname = "Trident"
                    tagresponse = s3c.put_bucket_tagging(Bucket=bucket,
                                                         Tagging={'TagSet': [
                                                             {'Key': 'Cost Center', 'Value': costcentername},
                                                             {'Key': 'Project', 'Value': projectname},
                                                             {'Key': 'Name', 'Value': bucket}]})
                    if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 204):
                        print(
                            "\nResource " + bucket.upper() + " tagged with Cost Center value of " + costcentername.upper() + " and project value of  " + projectname.upper() + " and the bucket name " + bucket.upper())


                elif (bucketname.lower().find("reporting") >= 0 or bucketname.lower().find("ds") >= 0):
                    costcentername = "Reporting"
                    projectname = "Reporting"
                    tagresponse = s3c.put_bucket_tagging(Bucket=bucket,
                                                         Tagging={'TagSet': [
                                                             {'Key': 'Cost Center', 'Value': costcentername},
                                                             {'Key': 'Project', 'Value': projectname},
                                                             {'Key': 'Name', 'Value': bucket}]})
                    if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 204):
                        print(
                            "\nResource " + bucket.upper() + " tagged with Cost Center value of " + costcentername.upper() + " and project value of  " + projectname.upper() + " and the bucket name " + bucket.upper())


                elif (bucketname.lower().find("bio") >= 0 or bucketname.lower().find(
                        "it") >= 0 or bucketname.lower().find("cf") >= 0):
                    try:
                        costcentername = "IT"
                        projectname = "IT"
                        print(bucket)
                        tagresponse = s3c.put_bucket_tagging(Bucket=bucket,
                                                             Tagging={'TagSet': [
                                                                 {'Key': 'Cost Center',
                                                                  'Value': costcentername},
                                                                 {'Key': 'Project', 'Value': projectname},
                                                                 {'Key': 'Name', 'Value': bucket}]})
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 204):
                            print(
                                "\nResource " + bucket.upper() + " tagged with Cost Center value of " + costcentername.upper() + " and project value of  " + projectname.upper() + " and the bucket name " + bucket.upper())



                    except s3c.exceptions.NoSuchBucket:
                        continue


                else:
                    costcentername = "Unknown"
                    projectname = "Unknown"
                    tagresponse = s3c.put_bucket_tagging(Bucket=bucket,
                                                         Tagging={'TagSet': [
                                                             {'Key': 'Cost Center', 'Value': costcentername},
                                                             {'Key': 'Project', 'Value': projectname},
                                                             {'Key': 'Name', 'Value': bucket}]})
                    if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 204):
                        print(
                            "\nResource " + bucket.upper() + " tagged with Cost Center value of " + costcentername.upper() + " and project value of  " + projectname.upper() + " and the bucket name " + bucket.upper())


def find_create_s3_tagset():
    s3 = boto3.resource('s3')
    s3c = boto3.client('s3')
    bucket_name = []
    print("Adding tags to buckets which don't have any tags: ")
    for bucket in s3.buckets.all():
        bucket_name.append(bucket.name)

    for bucket in bucket_name:
        try:
            s3c.get_bucket_tagging(Bucket=bucket)['TagSet']
        except ClientError:
            print(bucket)
            userr = click.prompt("\nDo you wish to add the tags now (yes/no) ")
            if (userr == "yes"):
                costcentervalue = click.prompt("Enter the value of name of the Cost Center")
                projectvalue = click.prompt("Enter the value of name of the Project")
                tagresponse = s3c.put_bucket_tagging(Bucket=bucket,
                                                     Tagging={'TagSet': [
                                                         {'Key': 'Cost Center', 'Value': costcentervalue},
                                                         {'Key': 'Project', 'Value': projectvalue},
                                                         {'Key': 'Name', 'Value': bucket}]})
                if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 204):
                    print(
                        "\nResource " + bucket.upper() + " tagged with Cost Center value of " + costcentervalue.upper() + " and project value of  " + projectvalue.upper() + " and the bucket name " + bucket.upper())
                exitstatus = click.prompt("Do you want to exit(yes/no) ")
                if (exitstatus == "yes"):
                    break;
                else:
                    continue
            elif (userr == "no"):
                exitstatus = click.prompt("Do you want to exit(yes/no) ")
                if (exitstatus == "yes"):
                    break;
                else:
                    continue




def find_untagged(tagname,service):
    if(service=="ec2"):
        find_ec2_tags(tagname)
        return "\nOperation Complete !!!"
    elif(service=="rs"):
        find_rs_tags(tagname)
        return "Operation Complete !!!"
    elif(service=="s3"):
        find_s3_bucket_with_missing_tags(tagname)
        return "\nOperation Complete !!!"

def find_notag_resources(service):
    if(service=="s3"):
        find_notag_s3()
        return "\nOperation Complete !!!"
    elif(service=="ec2"):
        ec2_with_no_tags()
        return "\nOperation Complete !!!"
    elif(service=="rs"):
        find_rsc_notags()
        return "\nOperation Complete !!!"


def ec2_with_no_tags():
    response = ec.describe_instances()
    print("Below are the Ec2 instances with no tags: \n")
    for r in response['Reservations']:
        if (('Tags' not in r['Instances'][0].keys()) and r['Instances'][0]['State']['Name'] != "terminated"):
            print("Instance " + r['Instances'][0]['InstanceId'] + " has no tags")
        


def find_rsc_notags():
    response = rs.describe_clusters()
    for r in response['Clusters']:
        if len(r['Tags']) == 0:
            print("Cluster " + r['ClusterIdentifier'] + " has no tags")
       



def find_notag_s3():
    s3 = boto3.resource('s3')
    s3c = boto3.client('s3')
    bucket_name = []
    print("Below are the buckets with no tags: ")
    for bucket in s3.buckets.all():
        bucket_name.append(bucket.name)

    for bucket in bucket_name:
        try:
            s3c.get_bucket_tagging(Bucket=bucket)['TagSet']
        except ClientError:
            print(bucket)


def find_replace_auto_untagged(tagname,service):
    if(service=="ec2"):
        find_replace_auto_ec2_tags(tagname)
        return "\nOperation Complete !!!"
    elif(service=="rs"):
        find_replace_auto_rs_tags(tagname)
        return "\nOperation Complete !!!"
    elif(service=="s3"):
        find_add_s3_auto_tags(tagname)
        return "\nOperation Complete !!!"

def find_s3_bucket_with_missing_tags(tagname):
    s3 = boto3.resource('s3')
    s3c = boto3.client('s3')
    bucket_name = []
    for bucket in s3.buckets.all():
        bucket_name.append(bucket.name)
    print("Printing buckets with missing tag: " + tagname.upper())
    for bucket in bucket_name:
        try:
            y = [z['Key'] for z in s3c.get_bucket_tagging(Bucket=bucket)['TagSet']]
            if (y.count(tagname) == 0):
                print(bucket)

        except ClientError:
            continue



def find_replace_auto_rs_tags(tagname):
    rsresponse = rs.describe_clusters(ClusterIdentifier='')
    count = 0
    print("The Clusters with no Tag are: \n")
    for r in rsresponse['Clusters']:
        y = [z['Key'] for z in r['Tags']]
        b = [c['Value'] for c in r['Tags'] if c['Key']=="Name"]
        if (y.count(tagname) == 0):
            print(r['ClusterIdentifier'])
            name = r['ClusterIdentifier']
            userresponse = click.prompt("\nDo you wish to add the tags now (yes/no) ")
            if (userresponse == "yes"):
                if (tagname == "Cost Center"):
                    if (b[0].lower().find("cloud") >= 0 or b[0].lower().find("devops") >= 0):
                        resourcename = 'arn:aws:redshift:us-east-1:672985825598:cluster:{0}'.format(name)
                        tagresponse = rs.create_tags(ResourceName=resourcename, Tags=[{'Key': tagname, 'Value': "Devops"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print("\nResource " + name + " tagged with Tag value of Devops")

                    elif (b[0].lower().find("reports") >= 0):
                        resourcename = 'arn:aws:redshift:us-east-1:672985825598:cluster:{0}'.format(name)
                        tagresponse = rs.create_tags(ResourceName=resourcename,
                                                 Tags=[{'Key': tagname, 'Value': "Reporting"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print("\nResource " + name + " tagged with Tag value of Reporting")

                    else:
                        resourcename = 'arn:aws:redshift:us-east-1:672985825598:cluster:{0}'.format(name)
                        tagresponse = rs.create_tags(ResourceName=resourcename,
                                                 Tags=[{'Key': tagname, 'Value': "Unknown"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print("\nResource " + name + " tagged with Tag value of Unknown")


                if (tagname == "Project"):
                    if (b[0].lower().find("cloud") >= 0 or b[0].lower().find("devops") >= 0):
                        resourcename = 'arn:aws:redshift:us-east-1:672985825598:cluster:{0}'.format(name)
                        tagresponse = rs.create_tags(ResourceName=resourcename, Tags=[{'Key': tagname, 'Value': "Devops"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print("\nResource " + name + " tagged with Tag value of Devops")

                    elif (b[0].lower().find("reports") >= 0):
                        resourcename = 'arn:aws:redshift:us-east-1:672985825598:cluster:{0}'.format(name)
                        tagresponse = rs.create_tags(ResourceName=resourcename,
                                                 Tags=[{'Key': tagname, 'Value': "Reporting"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print("\nResource " + name + " tagged with Tag value of Reporting")

                    else:
                        resourcename = 'arn:aws:redshift:us-east-1:672985825598:cluster:{0}'.format(name)
                        tagresponse = rs.create_tags(ResourceName=resourcename,
                                                 Tags=[{'Key': tagname, 'Value': "Unknown"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print("\nResource " + name + " tagged with Tag value of Unknown")

                if (tagname == "Name"):
                    if (len(b)==0):
                        resourcename = 'arn:aws:redshift:us-east-1:672985825598:cluster:{0}'.format(name)
                        tagresponse = rs.create_tags(ResourceName=resourcename, Tags=[{'Key': tagname, 'Value': name}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print("\nResource " + name + " tagged with Tag value of " + name)



def find_replace_auto_ec2_tags(tagname):
    ec2 = boto3.client('ec2')
    response = ec2.describe_instances()
    count = 0
    print("The Number of Instances with no Tag " + tagname + " are:\n")
    for r in response['Reservations']:
        y = [z['Key'] for z in r['Instances'][0]['Tags']]
        c = [d['Value'] for d in r['Instances'][0]['Tags'] if d['Key']=="Name"]
        if (y.count(tagname) == 0):
            print(r['Instances'][0]['InstanceId'])
            print(c)
            userr = click.prompt("\nDo you wish to add the tags now (yes/no) ")
            if(userr=="yes"):
                if(tagname=="Cost Center"):
                    if (c[0].lower().find("cloud") >= 0):
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "Devops"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print(
                                "\nResource " + r['Instances'][0]['InstanceId'] + " tagged\n with Tag value of Devops")
                    elif (c[0].lower().find("pvtrace") >= 0 or c[0].lower().find("littrace") >= 0 or c[0].lower().find(
                            "asrtrace") >= 0 or c[0].lower().find("safety") >= 0 or c[0].lower().find("custom") >= 0):
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "Safety"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print("Resource " + r['Instances'][0]['InstanceId'] + " tagged with Tag value of Safety")

                    elif (c[0].lower().find("ds") >= 0 or c[0].lower().find("reporting") >= 0):
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "Reporting"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print("Resource " + r['Instances'][0]['InstanceId'] + " tagged with Tag value of Reporting")

                    elif (c[0].lower().find("ctg") >= 0):
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "CTG"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print("Resource " + r['Instances'][0]['InstanceId'] + " tagged with Tag value of CTG")

                    elif (c[0].lower().find("trident") >= 0 or c[0].lower().find("irt") >= 0):
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "IRT"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print("Resource " + r['Instances'][0]['InstanceId'] + " tagged with Tag value of IRT")

                    elif (c[0].lower().find("it") >= 0 or c[0].lower().find("dc") >= 0 or c[0].lower().find("talari") >= 0 or c[0].lower().find("bi") >= 0):
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "IT"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print("Resource " + r['Instances'][0]['InstanceId'] + " tagged with Tag value of IT")
                    else:
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "Unknown"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print("Resource " + r['Instances'][0]['InstanceId'] + " tagged with Tag value of Unknown")





                elif (tagname == "Project"):
                    if (c[0].lower().find("cloud") >= 0):
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "Devops"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print(
                                "\nResource " + r['Instances'][0][
                                    'InstanceId'] + " tagged\n with Tag value of Devops")
                    elif (c[0].lower().find("pvtrace") >= 0):
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "Pvtrace"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print(
                                "Resource " + r['Instances'][0]['InstanceId'] + " tagged with Tag value of Pvtrace")

                    elif (c[0].lower().find("littrace") >= 0):
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "Littrace"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print(
                                "Resource " + r['Instances'][0]['InstanceId'] + " tagged with Tag value of Littrace")

                    elif (c[0].lower().find("asrtrace") >= 0):
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "Asrtrace"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print(
                                "Resource " + r['Instances'][0]['InstanceId'] + " tagged with Tag value of Asrtrace")

                    elif (c[0].lower().find("sigtrace") >= 0):
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "Sigtrace"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print(
                                "Resource " + r['Instances'][0]['InstanceId'] + " tagged with Tag value of Sigtrace")

                    elif (c[0].lower().find("custom") >= 0):
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "Abcube"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print(
                                "Resource " + r['Instances'][0]['InstanceId'] + " tagged with Tag value of Abcube")


                    elif (c[0].lower().find("ds") >= 0 or c[0].lower().find("reporting") >= 0):
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "Reporting"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print(
                                "Resource " + r['Instances'][0]['InstanceId'] + " tagged with Tag value of Reporting")

                    elif (c[0].lower().find("clinfeed") >= 0):
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "Clinfeed"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print("Resource " + r['Instances'][0]['InstanceId'] + " tagged with Tag value of Clinfeed")

                    elif (c[0].lower().find("trident") >= 0 or c[0].lower().find("irt") >= 0):
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "Trident"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print("Resource " + r['Instances'][0]['InstanceId'] + " tagged with Tag value of Trident")

                    elif (c[0].lower().find("it") >= 0 or c[0].lower().find("dc") >= 0 or c[0].lower().find("talari") >= 0 or c[0].lower().find("bi") >= 0):
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "IT"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print("Resource " + r['Instances'][0]['InstanceId'] + " tagged with Tag value of IT")

                    else:
                        tagresponse = ec2.create_tags(Resources=[r['Instances'][0]['InstanceId']],
                                                      Tags=[{'Key': tagname, 'Value': "Unknown"}])
                        if (tagresponse['ResponseMetadata']['HTTPStatusCode'] == 200):
                            print("Resource " + r['Instances'][0]['InstanceId'] + " tagged with Tag value of Unknown")

def find_add_s3_tags(tagname):
    s3 = boto3.resource('s3')
    s3c = boto3.client('s3')
    bucket_name = []
    for bucket in s3.buckets.all():
        bucket_name.append(bucket.name)

    for bucket in bucket_name:
        try:
            y = [z['Key'] for z in s3c.get_bucket_tagging(Bucket=bucket)['TagSet']]
            if (y.count(tagname) == 0):
                print(bucket)
                userresponse = click.prompt("\nDo you wish to add the tags now (yes/no) ")
                if (userresponse == "yes"):
                    value = click.prompt("What value of " + tagname + " you wish to enter ")
                    bucket_tagging = s3.BucketTagging(bucket)
                    tags = bucket_tagging.tag_set
                    tags.append({'Key': tagname, 'Value': value})
                    Set_Tag = bucket_tagging.put(Tagging={'TagSet': tags})
                    if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                        print("\nResource " + bucket.upper() + " tagged with Tag value of " + value)

                    exitstatus = click.prompt("Do you want to exit(yes/no) ")
                    if (exitstatus == "yes"):
                        break;
                    else:
                        continue

                elif(userresponse=="no"):
                    exitstatus = click.prompt("Do you want to exit(yes/no) ")
                    if (exitstatus == "yes"):
                        break;
                    else:
                        continue


        except ClientError:
            continue

def find_add_s3_auto_tags(tagname):

    bucket_name = []
    for bucket in s3.buckets.all():
        bucket_name.append(bucket.name)
    print("Printing buckets with missing tag: " + tagname.upper())
    for bucket in bucket_name:
        try:
            y = [z['Key'] for z in s3c.get_bucket_tagging(Bucket=bucket)['TagSet']]
            c = [d['Value'] for d in s3c.get_bucket_tagging(Bucket=bucket)['TagSet'] if d['Key']=="Name"]
            if (y.count(tagname) == 0):
                print(bucket)
                userresponse = click.prompt("\nDo you wish to add the tags now (yes/no) ")
                if (userresponse == "yes"):
                    if (tagname == "Cost Center"):
                        if (c[0].lower().find("cloud") >= 0 or c[0].lower().find("devops") >= 0):
                            bucket_tagging = s3.BucketTagging(bucket)
                            tags = bucket_tagging.tag_set
                            tags.append({'Key': tagname, 'Value': "Devops"})
                            Set_Tag = bucket_tagging.put(Tagging={'TagSet':tags})
                            if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                                print("\nResource " + bucket.upper() + " tagged with Tag value of " + " Devops".upper() )

                        elif (c[0].lower().find("safety") >= 0 or c[0].lower().find("trace") >= 0 or c[0].lower().find("abcube") >= 0 or c[0].lower().find("beanstalk") >= 0 or c[0].lower().find("easy") >= 0):
                            bucket_tagging = s3.BucketTagging(bucket)
                            tags = bucket_tagging.tag_set
                            tags.append({'Key': tagname, 'Value': "Safety"})
                            Set_Tag = bucket_tagging.put(Tagging={'TagSet':tags})
                            if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                                print("\nResource " + bucket.upper() + " tagged with Tag value of " + " Safety".upper())

                        elif (c[0].lower().find("reporting") >= 0 or c[0].lower().find("ds") >= 0):
                            bucket_tagging = s3.BucketTagging(bucket)
                            tags = bucket_tagging.tag_set
                            tags.append({'Key': tagname, 'Value': "Reporting"})
                            Set_Tag = bucket_tagging.put(Tagging={'TagSet':tags})
                            if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                                print("\nResource " + bucket.upper() + " tagged with Tag value of " + " Reporting".upper())

                        elif (c[0].lower().find("clinfeed") >= 0 or c[0].lower().find("ctg") >= 0 or c[0].lower().find("sharedservices") >= 0):
                            bucket_tagging = s3.BucketTagging(bucket)
                            tags = bucket_tagging.tag_set
                            tags.append({'Key': tagname, 'Value': "CTG"})
                            Set_Tag = bucket_tagging.put(Tagging={'TagSet':tags})
                            if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                                print("\nResource " + bucket.upper() + " tagged with Tag value of " + " CTG".upper())


                        elif (c[0].lower().find("trident") >= 0 or c[0].lower().find("irt") >= 0):
                            bucket_tagging = s3.BucketTagging(bucket)
                            tags = bucket_tagging.tag_set
                            tags.append({'Key': tagname, 'Value': "IRT"})
                            Set_Tag = bucket_tagging.put(Tagging={'TagSet':tags})
                            if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                                print("\nResource " + bucket.upper() + " tagged with Tag value of " + " IRT".upper())


                        elif (c[0].lower().find("bio") >= 0 or c[0].lower().find("cloudformation") >= 0 or c[0].lower().find("dr") >= 0):
                            bucket_tagging = s3.BucketTagging(bucket)
                            tags = bucket_tagging.tag_set
                            tags.append({'Key': tagname, 'Value': "IT"})
                            Set_Tag = bucket_tagging.put(Tagging={'TagSet':tags})
                            if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                                print("\nResource " + bucket.upper() + " tagged with Tag value of " + " IT".upper())

                    elif (tagname == "Project"):
                        if (c[0].lower().find("cloud") >= 0 or c[0].lower().find("devops") >= 0):
                            bucket_tagging = s3.BucketTagging(bucket)
                            tags = bucket_tagging.tag_set
                            tags.append({'Key': tagname, 'Value': "Devops"})
                            Set_Tag = bucket_tagging.put(Tagging={'TagSet':tags})
                            if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                                print("\nResource " + bucket.upper() + " tagged with Tag value of " + " Devops".upper())


                        if (c[0].lower().find("clinfeed") >= 0 or c[0].lower().find("ctg") >= 0):
                            bucket_tagging = s3.BucketTagging(bucket)
                            tags = bucket_tagging.tag_set
                            tags.append({'Key': tagname, 'Value': "Clinfeed"})
                            Set_Tag = bucket_tagging.put(Tagging={'TagSet':tags})
                            if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                                print("\nResource " + bucket.upper() + " tagged with Tag value of " + " Clinfeed".upper())

                        elif (c[0].lower().find("safety") >= 0 ):
                            bucket_tagging = s3.BucketTagging(bucket)
                            tags = bucket_tagging.tag_set
                            tags.append({'Key': tagname, 'Value': "Safety"})
                            Set_Tag = bucket_tagging.put(Tagging={'TagSet':tags})
                            if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                                print("\nResource " + bucket.upper() + " tagged with Tag value of " + " Safety".upper())


                        elif (c[0].lower().find("pvtrace") >= 0 or c[0].lower().find("beanstalk") >= 0 ):
                            bucket_tagging = s3.BucketTagging(bucket)
                            tags = bucket_tagging.tag_set
                            tags.append({'Key': tagname, 'Value': "Pvtrace"})
                            Set_Tag = bucket_tagging.put(Tagging={'TagSet':tags})
                            if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                                print("\nResource " + bucket.upper() + " tagged with Tag value of " + " Pvtrace".upper())



                        elif (c[0].lower().find("littrace") >= 0):
                            bucket_tagging = s3.BucketTagging(bucket)
                            tags = bucket_tagging.tag_set
                            tags.append({'Key': tagname, 'Value': "Littrace"})
                            Set_Tag = bucket_tagging.put(Tagging={'TagSet':tags})
                            if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                                print("\nResource " + bucket.upper() + " tagged with Tag value of " + " Littrace".upper())

                        elif (c[0].lower().find("sigtrace") >= 0):
                            bucket_tagging = s3.BucketTagging(bucket)
                            tags = bucket_tagging.tag_set
                            tags.append({'Key': tagname, 'Value': "Sigtrace"})
                            Set_Tag = bucket_tagging.put(Tagging={'TagSet':tags})
                            if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                                print("\nResource " + bucket.upper() + " tagged with Tag value of " + " sigtace".upper())


                        elif (c[0].lower().find("abcube") >= 0):
                            bucket_tagging = s3.BucketTagging(bucket)
                            tags = bucket_tagging.tag_set
                            tags.append({'Key': tagname, 'Value': "Abcube"})
                            Set_Tag = bucket_tagging.put(Tagging={'TagSet':tags})
                            if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                                print("\nResource " + bucket.upper() + " tagged with Tag value of " + " abcube".upper())


                        elif (c[0].lower().find("asrtrace") >= 0):
                            bucket_tagging = s3.BucketTagging(bucket)
                            tags = bucket_tagging.tag_set
                            tags.append({'Key': tagname, 'Value': "Asrtrace"})
                            Set_Tag = bucket_tagging.put(Tagging={'TagSet':tags})
                            if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                                print("\nResource " + bucket.upper() + " tagged with Tag value of " + " asrtrace".upper())


                        elif (c[0].lower().find("trident") >= 0 or c[0].lower().find("irt") >= 0):
                            bucket_tagging = s3.BucketTagging(bucket)
                            tags = bucket_tagging.tag_set
                            tags.append({'Key': tagname, 'Value': "Trident"})
                            Set_Tag = bucket_tagging.put(Tagging={'TagSet':tags})
                            if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                                print("\nResource " + bucket.upper() + " tagged with Tag value of " + " Trident".upper())


                        elif (c[0].lower().find("bio") >= 0 or c[0].lower().find("cloudformation") >= 0 or c[0].lower().find("dr") >= 0):
                            bucket_tagging = s3.BucketTagging(bucket)
                            tags = bucket_tagging.tag_set
                            tags.append({'Key': tagname, 'Value': "IT"})
                            Set_Tag = bucket_tagging.put(Tagging={'TagSet':tags})
                            if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                                print("\nResource " + bucket.upper() + " tagged with Tag value of " + " IT".upper())


                    elif (tagname == "Name"):
                        if (len(c)==0):
                            bucket_tagging = s3.BucketTagging(bucket)
                            tags = bucket_tagging.tag_set
                            tags.append({'Key': tagname, 'Value': bucket})
                            Set_Tag = bucket_tagging.put(Tagging={'TagSet':tags})
                            if (Set_Tag['ResponseMetadata']['HTTPStatusCode'] == 204):
                                print("\nResource " + bucket.upper() + " tagged with Tag value of " + bucket.upper())





        except ClientError:
            continue




@click.group()
def cli():
    """botocli manages services in aws"""

@cli.group('untag')
def untag():
    """ Commands for tagging and finding untagged resources"""

@untag.command('findreplace')
@click.option('--service', prompt='Enter the Service Name for which you want to find untagged resources ',
              help="Accepts a string value for the Service name")
@click.option('--tagname', prompt='Enter the Tag Name you want to find ',
              help="Accepts a string value for the tag name")

def find_replace_untagged_resources(tagname,service):
    resources = find_replace_untagged(tagname,service)
    print(resources)


@untag.command('find')
@click.option('--service', prompt='Enter the Service Name for which you want to find untagged resources ',
              help="Accepts a string value for the Service name")
@click.option('--tagname', prompt='Enter the Tag Name you want to find ',
              help="Accepts a string value for the tag name")

def find_untagged_resources(tagname,service):
    resources = find_untagged(tagname,service)
    print(resources)

@untag.command('notag')
@click.option('--service', prompt='Enter the Service Name for which you want to find resources with no tags ',
              help="Accepts a string value for the Service name")


def find_resources_with_notag(service):
    resources = find_notag_resources(service)
    print(resources)

@untag.command('createtag')
@click.option('--service', prompt='Enter the Service Name for which you want to find untagged resources ',
              help="Accepts a string value for the Service name")

def create_tags_services(service):
    resources = create_tags_for_notagresources(service)
    print(resources)

@untag.command('autocreatetag')
@click.option('--service', prompt='Enter the Service Name for which you want to find untagged resources ',
              help="Accepts a string value for the Service name")

def create_tags_automatically(service):
    resources = auto_create_tags(service)
    print(resources)




@untag.command('replaceauto')
@click.option('--service', prompt='Enter the Service Name for which you want to find untagged resources ',
              help="Accepts a string value for the Service name")
@click.option('--tagname', prompt='Enter the Tag Name you want to find ',
              help="Accepts a string value for the tag name")

def find_replace_resources_auto_untagged(tagname,service):
    resources = find_replace_auto_untagged(tagname,service)
    print(resources)


@cli.group('rdb')
def rdb():
    """ Commands for db's"""

@rdb.command('delete')
@click.option('--dname', prompt='Enter the Instance Name',
              help="Name of the DB Instance")
@click.option('--fsnap', prompt='Enter whether to keep snapshot or not',
              help="Boolean Value (true/false) , used to decide whether to keep the final snapshot ")
def delete_rdsinstance(dname,fsnap):
    """ command to delete the rds instances """
    db = del_dbs(dname,fsnap)
    #print(db)
    print("The Rds Instance {0} is {1}".format(db['DBInstance']['DBInstanceIdentifier'],db['DBInstance']['DBInstanceStatus']))






@rdb.command('ctags')
@click.option('--name', prompt='Enter the Instance Name',
              help="Accepts a string value for the tag name")
@click.option('--project', prompt='Enter the project name',help="Accepts a string value for the tag Cost Center")
@click.option('--env', prompt='Enter the Environment Name',
              help="Accepts a string value for the tag environment")



def create_tags(project,env,name):
    """ Command to create Tags for rds instances """
    instance = tag_dbs(name)
    tags = dbs.add_tags_to_resource(
    ResourceName=instance,
    Tags=[
        {
            'Key': 'Cost Center',
            'Value': project
        },
        {
            'Key': 'Environment',
            'Value': env
        }
    ]
)
    print("The Request Was Completed With The Status Code Of {0}".format(tags['ResponseMetadata']['HTTPStatusCode']))


@rdb.command('create')
@click.option('--storage', prompt='Size of the db hdd',
              help="Provide the size of the instance storage")
@click.option('--iclass', prompt='Instance Class',
              help="Provide the instance class")
@click.option('--identifier', prompt='Name of the instance',
              help="Provide the name of the instance")
@click.option('--username', prompt='username',
              help="Provide the username of the instance")
@click.option('--password', prompt='Password',hide_input=True,
              confirmation_prompt=True,help="Provide the password for the instance")
@click.option('--engine', prompt='Name of the db engine',
              help="Provide the name of the db engine")
@click.option('--sg', prompt='Id of the VPC SG',
              help="Provide the sg id")
@click.option('--dbsg', prompt='Name of subnet group',
              help="Provide the name of the db sybnet group")

def create_rdsinstance(storage,iclass,identifier,username,password,engine,sg,dbsg):
    """ Command for creating rds instances """
    instance = create_db(storage,iclass,identifier,username,password,engine,sg,dbsg)
    print("The instance {0} is {1}".format(instance['DBInstance']['DBInstanceIdentifier'],instance['DBInstance']['DBInstanceStatus']))



@rdb.command('listall')

def list_allrdsinstances():
    """ commands to list rds instances """
    db_list = dbs.describe_db_instances()
    for db in db_list['DBInstances']:
        print("RDS Instance {0} belongs to {1} engine and is {2}".format(db['DBInstanceIdentifier'],db['Engine'],db['DBInstanceStatus']))


@rdb.command('listdbs')
@click.option('--project', prompt='Project Name', help="Name of the Project")
@click.option('--env', prompt='Environment Name',type=click.Choice(['Dev','Val','Prod']),
              help="Name of the Environment")


def list_rdsinstances(project,env):
    """ commands to list project rds instances """
    db_instances = filter_dbs(project,env)
    for db in db_instances['ResourceTagMappingList']:
        db = str(db['ResourceARN'])
        dbsmod = db[38:]
        db_list = dbs.describe_db_instances(DBInstanceIdentifier=dbsmod)
        for db in db_list['DBInstances']:
            print("RDS Instance {0} belongs to {1} engine and is {2}".format(db['DBInstanceIdentifier'],db['Engine'],db['DBInstanceStatus']))

@rdb.command('start')
@click.option('--project', default=None,help="Name of the Project")
@click.option('--env', prompt='Environment Name',
              help="Name of the Environment")

def start_rdsinstances(project,env):
    """ Command to start rds instances """
    db_instances = filter_dbs(project,env)
    for db in db_instances['ResourceTagMappingList']:
        try:
            db = str(db['ResourceARN'])
            dbsmod = db[38:]
            db_list = dbs.start_db_instance(DBInstanceIdentifier=dbsmod)
            print("starting the instance {0}".format(db_list['DBInstance']['DBInstanceIdentifier']))

        except dbs.exceptions.InvalidDBInstanceStateFault:
            pass
            print("{0} Instance is already started".format(dbsmod))


@rdb.command('stop')
@click.option('--project', default=None,help="Name of the Project")
@click.option('--env', prompt='Environment Name',
              help="Name of the Environment")
def stop_rdsinstances(project,env):
    """ Command for stopping rds instances """
    db_instances = filter_dbs(project,env)
    for db in db_instances['ResourceTagMappingList']:
        try:
            db = str(db['ResourceARN'])
            dbsmod = db[38:]
            db_list = dbs.stop_db_instance(DBInstanceIdentifier=dbsmod)
            print("stopping the instance {0}".format(db_list['DBInstance']['DBInstanceIdentifier']))

        except dbs.exceptions.InvalidDBInstanceStateFault:
            pass
            print("{0} Instance has already stopped or it is stopping".format(dbsmod))

@rdb.command('modify')
@click.option('--gname',default=None, help="Provide the Parameter Group Name")
@click.option('--pname',multiple=True,
              help="Provide the parameter name")
@click.option('--pvalue',multiple=True,
              help="Provide the parameter value")
@click.option('--am',multiple=True,
              help=" Provide the apply method")
def modify_pgs(gname,pname,pvalue,am):
    """ Command to modify parameter group """
    pg = mod_pg(pname,pvalue,am,gname)
    print(pg['ResponseMetadata']['HTTPStatusCode'])


@cli.group('lb')
def lb():
    """Commands for load balancers"""
@lb.command('listalbs')
@click.option('--project', default=None,help="Name of the Project")
def list_loadbalancers(project):
    "Lists the ELBv2's"
    loadbalancers = elbList.describe_load_balancers()
    "List the lb's"
    for elb in loadbalancers['LoadBalancers']:
        print('ELBv2 Name : ' + elb['LoadBalancerName'])

"""
@lb.command('listtargetgroups')
@click.option('--project', default=None,help="only the targets for the project (tag Project:<name>)")
def list_targetgroups(project):
    loadbalancers = elbList.describe_target_groups()
    "List Targetgroups in the ELB"
    for elb in loadbalancers['TargetGroups']:
        print('ELB Target group Name : ' + elb['TargetGroupName'])
    return
"""
@lb.command('listtargetgroups')
@click.option('--lb', default=None,help="Name of the Load balancer")

def lst_tg(lb):
    "List Targetgroups in the ELB"
    target_groups = list_tg(lb)
    for tg in target_groups:
        print(tg)

@lb.command('listtargets')
@click.option('--lb', default=None,help="Name of the Load balancer")

def lst_tg(lb):
    "List Targets in the ELB"
    targets = list_targets(lb)
    for tg in targets:
        print(tg)


@lb.command('removetargets')
@click.option('--lb', default=None,help="Name of the Load balancer")

def rm_targets(lb):
     "removes the targets from a targetgroup"
     target_id = rmv_tgts(lb)
     Targets = []
     Target = {}
     Target['Id'] = target_id
     Targets.append(Target)
     Tgroup =  rmv_tg(lb)
     lbs = elbList.deregister_targets(TargetGroupArn=Tgroup,Targets=Targets)
     print(lbs)


@lb.command('addtargets')
@click.option('--project', default=None,help="Name of the project")
@click.option('--lb', prompt='Loadbalancer Name',
              help="Name of the Load balancer")
def add_targets(project,lb):
     "adds the targets to the targetgroup"
     target_id = tar_instances(project)
     for i in target_id:
        Targets = []
        Target = {}
        Target['Id'] = i.id
        Target['Port'] = 80
        Targets.append(Target)
     print(Targets)
     Tgroup =  rmv_tg(lb)
     lbs = elbList.register_targets(TargetGroupArn=Tgroup,Targets=Targets)
     print(lbs)



@cli.group('costs')
def costs():
    """Commands for showing costs"""

@costs.command('costscc')

@click.option('--costcenter', default=None,
    help="Name of the Cost Center")
@click.option('--day', prompt='Enter the days',
              help="Number of days")
def list_costs(costcenter,day):
     """ Shows the costs associated with individual resources of a project environment """
     cost_explorer = total_cost(costcenter,day)
     print(cost_explorer)

@costs.command('projectcost')
@click.option('--project', prompt='Enter the Project Name', default=None,
    help="Name of the project")
@click.option('--day', prompt='Enter the days',
              help="Number of days")

def list_projectcosts(project,day):
     """ Shows the costs associated with all the services of a project environment """
     cost_explorer = project_totalcost(project,day)
     print(cost_explorer)


@costs.command('pcostenv')
@click.option('--project', default=None,
    help="Name of the project")
@click.option('--day', prompt='Enter the days',
              help="Number of days")
@click.option('--environment', prompt='Enter the environment name',
              help="Name of the environment")

def show_projectcost_with_env(project,day,environment):
    """ Shows the costs associated with individual resources of a Project """
    cost_project = sh_projectcost_with_env(project,day,environment)
    print(cost_project)


@costs.command('pcostwd')
@click.option('--project', default=None,
    help="Name of the project")
@click.option('--day', prompt='Enter the days',
              help="Number of days for which cost is calculated")
def show_project_cost_with_dimensions(project,day):
     """ Shows the total Costs associated with the Project """
     cost_explorer = sh_project_cost_with_dimensions(project,day)
     print(cost_explorer)

@costs.command('listdimension')
def show_dimension():
    """ lists all the dimensions for cost explorer """
    dimensions = sh_dimension()
    for dimension in dimensions['DimensionValues']:
        print(dimension['Value'])


@cli.group('snapshots')
def snapshots():
    """Commands for snapshots"""

@snapshots.command('delete')
@click.option('--days',prompt='Number of Days',type=int,
    help="Number of days")
def delete_ebssnapshots(days):
    """ Deletes the snaphsots from a certain Time Range """
    snapshot = delete_snapshots(days)
    print(snapshot)
    snaps = list_ebssnapshots()
    print(snaps)


@snapshots.command('list')
@click.option('--project', default=None,
    help="Only snapshots for certain project")
@click.option('--env', prompt='Environment Name',
              help="Only instances for certain environment")
@click.option('--all', 'list_all', default=False, is_flag=True,
    help="List all snapshots for each volume, not just the most recent")
def list_snapshots(project, list_all,env):
    "List EC2 snapshots"

    instances = filter_instances(project,env)

    for i in instances:
        for v in i.volumes.all():
            for s in v.snapshots.all():
                print(", ".join((
                    s.id,
                    v.id,
                    i.id,
                    s.state,
                    s.progress,
                    s.start_time.strftime("%c")
                )))

                if s.state == 'completed' and not list_all: break

    return

@cli.group('volumes')
def volumes():
    """Commands for volumes"""

@volumes.command('list')
@click.option('--project', default=None,
    help="Only volumes for certain project")
@click.option('--env', prompt='Environment Name',
              help="Only instances for certain environment")
def list_volumes(project,env):
    "List EC2 volumes"

    instances = filter_instances(project,env)

    for i in instances:
        for v in i.volumes.all():
            print(", ".join((
                v.id,
                i.id,
                v.state,
                str(v.size) + "GiB",
                v.encrypted and "Encrypted" or "Not Encrypted"
            )))

    return

@cli.group('instances')
def instances():
    """Commands for instances"""

@instances.command('snapshot',
    help="Create snapshots of all volumes")
@click.option('--project', default=None,
    help="Name of the project")
@click.option('--env', prompt='Environment Name',
              help="Name of the Environment")
def create_snapshots(project,env):
    "Create snapshots for EC2 instances"

    instances = filter_instances(project,env)

    for i in instances:
        print("Stopping {0}...".format(i.id))

        i.stop()
        i.wait_until_stopped()

        for v in i.volumes.all():
            if has_pending_snapshot(v):
                print("  Skipping {0}, snapshot already in progress".format(v.id))
                continue

            print("  Creating snapshot of {0}".format(v.id))
            v.create_snapshot(Description="Created by SnapshotAlyzer 30000")

        print("Starting {0}...".format(i.id))

        i.start()
        i.wait_until_running()

    print("Job's done!")

    return

@instances.command('list',help="Lists the instances of a certain project")
@click.option('--project', default=None,
    help="Name of the project")
@click.option('--env', prompt='Environment Name',
              help="Name of the Environment")
def list_instances(project,env):
    "List EC2 instances"
    instances = filter_instances(project,env)

    for i in instances:
        tags = { t['Key']: t['Value'] for t in i.tags or [] }
        print(', '.join((
            i.id,
            i.instance_type,
            i.placement['AvailabilityZone'],
            i.state['Name'],
            i.public_dns_name,
            tags.get('Environment', '<no environment>'),
            tags.get("Cost Center", '<no project>')
            )))

    return


@instances.command('stop')
@click.option('--project', default=None,
  help='Enter the Project Name')
@click.option('--env', prompt='Environment Name',
              help="Enter the Name of the environment")
def stop_instances(project,env):
    "Stop EC2 instances"

    instances = filter_instances(project,env)

    for i in instances:
        print("Stopping {0}...".format(i.id))
        try:
            i.stop()
        except botocore.exceptions.ClientError as e:
            print(" Could not stop {0}. ".format(i.id) + str(e))
            continue

    return

@instances.command('start')
@click.option('--project', default=None,
  help='Enter the name of the Project')
@click.option('--env', prompt='Environment Name',
              help="Enter the name of the environment (Dev/Val/Prod)")
def start_instances(project,env):
    "Start EC2 instances"

    instances = filter_instances(project,env)

    for i in instances:
        print("Starting {0}...".format(i.id))
        try:
            i.start()
        except botocore.exceptions.ClientError as e:
            print(" Could not start {0}. ".format(i.id) + str(e))
            continue

    return

if __name__ == '__main__':
    cli()
